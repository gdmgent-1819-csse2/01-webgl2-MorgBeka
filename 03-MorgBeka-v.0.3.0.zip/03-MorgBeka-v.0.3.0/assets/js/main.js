import Application from './Application.js'

window.addEventListener('DOMContentLoaded', _ => new Application(), false)